import tkinter as tk
from tkinter import ttk
from tkinter import filedialog
import PyPDF2
from PIL import Image, ImageTk
from pdf2image import convert_from_path

class PDFViewerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("PDF Viewer App")
        
        # Create a frame for the PDF viewer
        self.pdf_frame = tk.Frame(self.root)
        self.pdf_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create a Canvas to display PDF pages
        self.canvas = tk.Canvas(self.pdf_frame)
        self.canvas.pack(fill=tk.BOTH, expand=True)
        
        # Add scrollbar to navigate through pages
        self.scrollbar = ttk.Scrollbar(self.pdf_frame, orient="vertical", command=self.canvas.yview)
        self.scrollbar.pack(side="right", fill="y")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        
        # Bind mouse scroll to change pages
        self.canvas.bind_all("<MouseWheel>", self.scroll_pages)
        
        # Load PDF file
        self.pdf_file_path = None

        # Button to open PDF file
        self.open_button = ttk.Button(root, text="Open PDF", command=self.open_pdf)
        self.open_button.pack()

    def open_pdf(self):
        self.pdf_file_path = filedialog.askopenfilename(filetypes=[("PDF Files", "*.pdf")])
        if self.pdf_file_path:
            self.show_pdf()

    def show_pdf(self):
        # Clear previous content
        self.canvas.delete("all")

        # Convert PDF pages to images
        pages = convert_from_path(self.pdf_file_path)

        # Display PDF pages
        for i, page in enumerate(pages):
            # Convert PIL image to Tkinter PhotoImage
            img = ImageTk.PhotoImage(page)
            # Add image to canvas
            self.canvas.create_image(0, i * page.height, anchor="nw", image=img)
            # Keep a reference to the image to prevent it from being garbage collected
            self.canvas.image = img
        
        # Update canvas scroll region
        self.canvas.config(scrollregion=self.canvas.bbox("all"))

    def scroll_pages(self, event):
        if event.delta < 0:
            self.canvas.yview_scroll(1, "units")
        else:
            self.canvas.yview_scroll(-1, "units")

# Create the main Tkinter window
root = tk.Tk()
app = PDFViewerApp(root)
root.mainloop()
