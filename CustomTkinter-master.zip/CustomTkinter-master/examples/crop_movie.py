# # # # from moviepy.editor import VideoFileClip

# # # # video = VideoFileClip("C:/Users/Mansi/Downloads/CustomTkinter-master/CustomTkinter-master/examples/C0028.mp4")

# # # # # Calculate the center coordinates of the video
# # # # center_x = video.w / 7
# # # # center_y = video.h / 7

# # # # # Calculate the top-left coordinates of the crop box
# # # # crop_x = center_x - 1080 / 2
# # # # crop_y = center_y - 1350 / 2

# # # # # Crop to 1080x1350 size
# # # # video = video.crop(x1=crop_x, y1=crop_y, width=1080, height=1350)

# # # # # Replace 'cropped_video.mp4' with the name of your output file
# # # # video.write_videofile('cropped_video.mp4')


# # # # from moviepy.editor import VideoFileClip

# # # # def crop_video(input_path, output_path):
# # # #     video = VideoFileClip(input_path)
# # # #     center_x = video.w / 2
# # # #     center_y = video.h / 2
# # # #     crop_x = center_x - 1080 / 2
# # # #     crop_y = center_y - 1350 / 2
# # # #     cropped_video = video.crop(x1=crop_x, y1=crop_y, width=1080, height=1350)
# # # #     cropped_video.write_videofile(output_path)

# # # import cv2
# # # import numpy as np

# # # video_path = "C:/Users/Mansi/Downloads/CustomTkinter-master/CustomTkinter-master/examples/C0028.mp4"  # Change this to your video file path
# # # cap = cv2.VideoCapture(video_path)

# # # if not cap.isOpened():
# # #     print("Error: Could not open video.")
# # #     exit()

# # # mouse_pressed = False
# # # starting_x = starting_y = ending_x = ending_y = -1

# # # def mousebutton(event, x, y, flags, param):
# # #     global img_dup, starting_x, starting_y, ending_x, ending_y, mouse_pressed
# # #     if event == cv2.EVENT_LBUTTONDOWN:
# # #         mouse_pressed = True
# # #         starting_x, starting_y = x, y
# # #         img_dup = np.copy(frame)

# # #     elif event == cv2.EVENT_MOUSEMOVE:
# # #         if mouse_pressed:
# # #             img_dup = np.copy(frame)
# # #             cv2.rectangle(img_dup, (starting_x, starting_y), (x, y), (0, 255, 0), 1)

# # #     elif event == cv2.EVENT_LBUTTONUP:
# # #         mouse_pressed = False
# # #         ending_x, ending_y = x, y

# # # cv2.namedWindow('video')
# # # cv2.setMouseCallback('video', mousebutton)

# # # while True:
# # #     ret, frame = cap.read()
# # #     if not ret:
# # #         break

# # #     img_dup = np.copy(frame)

# # #     cv2.imshow('video', img_dup)
# # #     k = cv2.waitKey(1)

# # #     if k == ord('c'):
# # #         if starting_y > ending_y:
# # #             starting_y, ending_y = ending_y, starting_y
# # #         if starting_x > ending_x:
# # #             starting_x, ending_x = ending_x, starting_x
# # #         if ending_y - starting_y > 1 and ending_x - starting_x > 0:
# # #             image = frame[starting_y:ending_y, starting_x:ending_x]
# # #             img_dup = np.copy(image)
# # #     elif k == 27:
# # #         break

# # # cap.release()
# # # cv2.destroyAllWindows()


# # # Python 2/3 compatibility
# # from __future__ import print_function
# # # Allows use of print like a function in Python 2.x

# # # Import OpenCV and Numpy modules
# # import numpy as np
# # import cv2


# # try:
# #     # Create a named window to display video output
# #     cv2.namedWindow('Watermark', cv2.WINDOW_NORMAL)
# #     # Load logo image
# #     dog = cv2.imread('Intel_Logo.png')
# #     # 
# #     rows,cols,channels = dog.shape
# #     # Convert the logo to grayscale
# #     dog_gray = cv2.cvtColor(dog,cv2.COLOR_BGR2GRAY)
# #     # Create a mask of the logo and its inverse mask
# #     ret, mask = cv2.threshold(dog_gray, 10, 255, cv2.THRESH_BINARY)
# #     mask_inv = cv2.bitwise_not(mask)
# #     # Now just extract the logo
# #     dog_fg = cv2.bitwise_and(dog,dog,mask = mask)
# #     # Initialize Default Video Web Camera for capture.
# #     webcam = cv2.VideoCapture("examples/Trim.mp4")
# #     # Check if Camera initialized correctly
# #     success = webcam.isOpened()
# #     if success == False:
# #         print('Error: Camera could not be opened')
# #     else:
# #         print('Sucess: Grabbing the camera')
# #         webcam.set(cv2.CAP_PROP_FPS,30);
# #         webcam.set(cv2.CAP_PROP_FRAME_WIDTH,1024);
# #         webcam.set(cv2.CAP_PROP_FRAME_HEIGHT,768);

# #     while(True):
# #         # Read each frame in video stream
# #         ret, frame = webcam.read()
# #         # Perform operations on the video frames here
# #         # To put logo on top-left corner, create a Region of Interest (ROI)
# #         roi = frame[0:rows, 0:cols ] 
# #         # Now blackout the area of logo in ROI
# #         frm_bg = cv2.bitwise_and(roi,roi,mask = mask_inv)
# #         # Next add the logo to each video frame
# #         dst = cv2.add(frm_bg,dog_fg)
# #         frame[0:rows, 0:cols ] = dst
# #         # Overlay Text on the video frame with Exit instructions
# #         font = cv2.FONT_HERSHEY_SIMPLEX
# #         cv2.putText(frame, "Type q to Quit:",(50,700), font, 1,(255,255,255),2,cv2.LINE_AA)
# #         # Display the resulting frame
# #         # Display the resulting frame
# #         cv2.imshow('Watermark',frame)
# #         # Wait for exit key "q" to quit
# #         if cv2.waitKey(1) & 0xFF == ord('q'):
# #             break

# #     # Release all resources used
# #     webcam.release()
# #     cv2.destroyAllWindows()

# # except cv2.error as e:
# #     print('Please correct OpenCV Error')


# import cv2
# cap =  cv2.VideoCapture("C:/Users/Mansi/Downloads/CustomTkinter-master/CustomTkinter-master/examples/C0028.MP4")

# while True:
#     _,image = cap.read()
#     A = image[0:200, 0:100]
#     # B = image[200:600, 200:450]

#     cv2.imshow("Tom and jerry_1", A)
#     # cv2.imshow("Tom and jerry_1", B)

#     if cv2.waitKey(15) == 13:
#         break

# cv2.destroyAllWindows()


# import os
# from moviepy.editor import VideoFileClip,concatenate_videoclips
# import moviepy.editor as mpy
# from moviepy.video.fx.all import crop

# # path of the video file to be cropped
# path = "C:/Users/Mansi/Downloads/CustomTkinter-master/CustomTkinter-master/examples/crop/"


# #path of the video file to be saved after cropping
# output_video = "C:/Users/Mansi/Downloads/CustomTkinter-master/CustomTkinter-master/examples/crop/cropped.mp4"


# for filename in os.listdir(path):

#         clip = mpy.VideoFileClip(path+filename)
#         (w, h) = clip.size
#         cropped_clip = crop(clip, width=600, height=5000, x_center=w/2, y_center=h/2)
#         cropped_clip.write_videofile(output_video+filename,codec="libx264")


import cv2

# Global variables
refPt = []
cropping = False

def click_and_crop(event, x, y, flags, param):
    global refPt, cropping

    if event == cv2.EVENT_LBUTTONDOWN:
        refPt = [(x, y)]
        cropping = True

    elif event == cv2.EVENT_MOUSEMOVE:
        if cropping:
            clone = frame.copy()
            cv2.rectangle(clone, refPt[0], (x, y), (0, 255, 0), 2)
            cv2.imshow("Video", clone)

    elif event == cv2.EVENT_LBUTTONUP:
        refPt.append((x, y))
        cropping = False

        cv2.rectangle(frame, refPt[0], refPt[1], (0, 255, 0), 2)
        cv2.imshow("Video", frame)

def crop_video(input_file, output_file):
    global frame

    cap = cv2.VideoCapture(input_file)
    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_file, fourcc, fps, (width, height))

    cv2.namedWindow("Video")
    cv2.setMouseCallback("Video", click_and_crop)

    while True:
        ret, frame = cap.read()

        if not ret:
            break

        clone = frame.copy()

        if len(refPt) == 2:
            roi = clone[refPt[0][1]:refPt[1][1], refPt[0][0]:refPt[1][0]]
            out.write(roi)

        cv2.imshow("Video", frame)
        key = cv2.waitKey(1) & 0xFF 
    
        if key == ord("q"):
            break

    cap.release()
    out.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    input_file = "C:/Users/Mansi/Downloads/CustomTkinter-master/CustomTkinter-master/examples/crop/Trim.mp4"
    output_file = "C:/Users/Mansi/Downloads/CustomTkinter-master/CustomTkinter-master/examples/crop/output.mp4"
    crop_video(input_file, output_file)
