# import tkinter as tk
# from tkinter import filedialog
# import subprocess

# class PythonCompilerApp:
#     def __init__(self, master):
#         self.master = master
#         master.title("Python Compiler")

#         self.script_text = tk.Text(master, wrap="word", height=20, width=50)
#         self.script_text.pack(padx=10, pady=10, side=tk.LEFT)

#         self.scrollbar = tk.Scrollbar(master, command=self.script_text.yview)
#         self.scrollbar.pack(side=tk.LEFT, fill='y')

#         self.script_text.config(yscrollcommand=self.scrollbar.set)

#         self.run_button = tk.Button(master, text="Run", command=self.run_script)
#         self.run_button.pack(pady=10)

#         self.hide_button = tk.Button(master, text="Hide Script", command=self.hide_script)
#         self.hide_button.pack(pady=5)

#         self.show_button = tk.Button(master, text="Show Script", command=self.show_script)
#         self.show_button.pack(pady=5)

#     def open_script(self):
#         file_path = filedialog.askopenfilename(initialdir="/", title="Select Python Script",
#                                                filetypes=(("Python files", "*.py"), ("all files", "*.*")))
#         if file_path:
#             with open(file_path, 'r') as file:
#                 script_content = file.read()
#                 self.script_text.insert(tk.END, script_content)

#     def run_script(self):
#         script_content = self.script_text.get("1.0", tk.END)
#         with open("temp_script.py", 'w') as file:
#             file.write(script_content)

#         try:
#             result = subprocess.check_output(["python", "temp_script.py"], stderr=subprocess.STDOUT, universal_newlines=True)
#             print(result)
#         except subprocess.CalledProcessError as e:
#             print(e.output)

#     def hide_script(self):
#         self.script_text.pack_forget()

#     def show_script(self):
#         self.script_text.pack(side=tk.LEFT, padx=10, pady=10)

# root = tk.Tk()
# app = PythonCompilerApp(root)
# root.mainloop()


import tkinter as tk
from tkinter import ttk
import sys
from io import StringIO

class CustomCompilerApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Custom Compiler")

        self.create_widgets()

    def create_widgets(self):
        self.code_editor = tk.Text(self, height=20, width=60)
        self.code_editor.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        run_button = ttk.Button(self, text="Run", command=self.run_code)
        run_button.pack(pady=5)

        self.output_text = tk.Text(self, height=10, width=60, state=tk.DISABLED)
        self.output_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

    def run_code(self):
        # Clear previous output
        self.output_text.config(state=tk.NORMAL)
        self.output_text.delete(1.0, tk.END)

        # Capture stdout
        sys.stdout = StringIO()
        try:
            code = self.code_editor.get("1.0", tk.END)
            exec(code)
            output = sys.stdout.getvalue()
            self.output_text.insert(tk.END, output)
        except Exception as e:
            error_message = f"Error: {e}"
            self.output_text.insert(tk.END, error_message)
        finally:
            sys.stdout = sys.__stdout__
            self.output_text.config(state=tk.DISABLED)


if __name__ == "__main__":
    app = CustomCompilerApp()
    app.mainloop()
