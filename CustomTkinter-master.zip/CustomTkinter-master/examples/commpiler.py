# import tkinter as tk
# from tkinter import ttk, scrolledtext
# from pygments.lexers import PythonLexer
# from pygments.styles import get_style_by_name
# from pygments.token import Token
# from pygments import highlight
# import sys
# from io import StringIO


# class CustomCompilerApp(tk.Tk):
#     def __init__(self):
#         super().__init__()
#         self.title("Custom Compiler")
#         self.configure(background='black')

#         self.create_widgets()

#     def create_widgets(self):
#         self.code_editor = scrolledtext.ScrolledText(self, height=20, width=60, bg='black', fg='white', insertbackground='white')
#         self.code_editor.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

#         run_button = ttk.Button(self, text="Run", command=self.run_code)
#         run_button.pack(pady=5)

#         self.output_text = scrolledtext.ScrolledText(self, height=10, width=60, bg='black', fg='white')
#         self.output_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

#         # Apply syntax highlighting
#         self.code_editor.tag_configure("Token.Keyword", foreground="orange")
#         self.code_editor.tag_configure("Token.Comment", foreground="grey")
#         self.code_editor.tag_configure("Token.String", foreground="green")
#         self.code_editor.tag_configure("Token.Name.Function", foreground="blue")

#     def highlight_code(self, code):
#         self.code_editor.delete(1.0, tk.END)
#         highlighted_code = highlight(code, PythonLexer(), get_style_by_name("monokai"))
#         self.code_editor.insert(tk.END, highlighted_code)

#     def run_code(self):
#         # Clear previous output
#         self.output_text.config(state=tk.NORMAL)
#         self.output_text.delete(1.0, tk.END)

#         # Capture stdout
#         sys.stdout = StringIO()
#         try:
#             code = self.code_editor.get("1.0", tk.END)
#             exec(code)
#             output = sys.stdout.getvalue()
#             self.output_text.insert(tk.END, output)
#         except Exception as e:
#             error_message = f"Error: {e}"
#             self.output_text.insert(tk.END, error_message)
#         finally:
#             sys.stdout = sys.__stdout__
#             self.output_text.config(state=tk.DISABLED)


# if __name__ == "__main__":
#     app = CustomCompilerApp()
#     app.mainloop()


import requests

def compile_code(code, language, input_text=""):
    url = "https://ideone.com/api/1/service"
    data = {
        "sourceCode": code,
        "language": language,
        "input": input_text,
        "run": True
    }
    response = requests.post(url, json=data)
    if response.status_code == 200:
        result = response.json()
        if result["status"] == "0":
            return result["output"]
        else:
            return f"Compilation error: {result['cmpinfo']}"
    else:
        return "Error occurred while connecting to the compiler service."

if __name__ == "__main__":
    code = '''
    #include <stdio.h>
    int main() {
        printf("Hello, world!\\n");
        return 0;
    }
    '''
    language = 28  # 28 for C
    input_text = ""  # You can provide input if needed

    output = compile_code(code, language, input_text)
    print("Output:")
    print(output)
