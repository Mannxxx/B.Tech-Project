import tkinter as tk
import tkinter
import vlc
import tkinter.simpledialog
from tkinter import filedialog, Text, messagebox
import customtkinter
import os
import webbrowser
from moviepy.video.io.ffmpeg_tools import ffmpeg_extract_subclip
from PyPDF2 import PdfFileReader
import vlc
from PIL import Image, ImageTk
from moviepy.editor import VideoFileClip
from tkPDFViewer import tkPDFViewer as pdf
from CTkPDFViewer import *

customtkinter.set_appearance_mode("System")  # Modes: "System" (standard), "Dark", "Light")
customtkinter.set_default_color_theme("blue")  # Themes: "blue" (standard), "green", "dark-blue")

class App(customtkinter.CTk):
    def __init__(self):
        super().__init__()

        # configure window
        self.title("BladeSense.py")
        self.geometry(f"{1100}x580")

        # configure grid layout (4x4)
        self.grid_columnconfigure(1, weight=1)
        self.grid_columnconfigure((2, 3), weight=0)
        self.grid_rowconfigure((0, 1, 2), weight=1)

        # create sidebar frame with widgets
        self.sidebar_frame = customtkinter.CTkFrame(self, width=140, corner_radius=0)
        self.sidebar_frame.grid(row=0, column=0, rowspan=4, sticky="nsew")
        self.sidebar_frame.grid_rowconfigure(4, weight=1)
        self.logo_label = customtkinter.CTkLabel(self.sidebar_frame, text="BladeSense", font=customtkinter.CTkFont(size=20, weight="bold"))
        self.logo_label.grid(row=0, column=0, padx=20, pady=(20, 10))
        self.sidebar_button_1 = customtkinter.CTkButton(self.sidebar_frame, command=self.show_home_page, text="Home")
        self.sidebar_button_1.grid(row=1, column=0, padx=20, pady=10)
        self.sidebar_button_1 = customtkinter.CTkButton(self.sidebar_frame, command=self.show_tools_page, text="Tools")
        self.sidebar_button_1.grid(row=2, column=0, padx=20, pady=10)
        self.sidebar_button_2 = customtkinter.CTkButton(self.sidebar_frame, command=self.show_documentation_page, text="Documentation")
        self.sidebar_button_2.grid(row=4, column=0, padx=20, pady=10)
        self.sidebar_button_3 = customtkinter.CTkButton(self.sidebar_frame, command=self.show_run_page, text="Run")
        self.sidebar_button_3.grid(row=3, column=0, padx=20, pady=10)
        self.appearance_mode_label = customtkinter.CTkLabel(self.sidebar_frame, text="Appearance Mode:", anchor="w")
        self.appearance_mode_label.grid(row=5, column=0, padx=20, pady=(10, 0))
        self.appearance_mode_optionemenu = customtkinter.CTkOptionMenu(self.sidebar_frame, values=["Light", "Dark", "System"],
                                                                       command=self.change_appearance_mode_event)
        self.appearance_mode_optionemenu.grid(row=6, column=0, padx=20, pady=(10, 10))
        self.scaling_label = customtkinter.CTkLabel(self.sidebar_frame, text="UI Scaling:", anchor="w")
        self.scaling_label.grid(row=7, column=0, padx=20, pady=(10, 0))
        self.scaling_optionemenu = customtkinter.CTkOptionMenu(self.sidebar_frame, values=["80%", "90%", "100%", "110%", "120%"],
                                                               command=self.change_scaling_event)
        self.scaling_optionemenu.grid(row=8, column=0, padx=20, pady=(10, 20))

        # create tools frame
        self.tools_frame = customtkinter.CTkFrame(self, corner_radius=0, fg_color="transparent")
        self.tools_frame.grid_columnconfigure(0, weight=1)

        # set default values
        self.appearance_mode_optionemenu.set("Dark")
        self.scaling_optionemenu.set("100%")

        # Frames for different pages
        self.home_frame = customtkinter.CTkFrame(self, width=900, height=480)
        self.tools_frame = customtkinter.CTkFrame(self, width=900, height=980)
        self.documentation_frame = customtkinter.CTkFrame(self, width=900, height=480)
        self.run_frame = customtkinter.CTkFrame(self, width=900, height=480)

        # Create a frame for the PDF viewer within the documentation_frame
        self.pdf_viewer_frame = customtkinter.CTkFrame(self.documentation_frame)
        self.pdf_viewer_frame.grid(row=0, column=0, padx=20, pady=20, sticky="nsew")
    
        # Initialize the PDF viewer within the created frame
        self.pdf_viewer = CTkPDFViewer(self.pdf_viewer_frame, file="C:/Users/Mansi/Downloads/CustomTkinter-master/CustomTkinter-master/examples/phonetics.pdf", width=900, height=600)
        self.pdf_viewer.pack(fill="both", expand=True)

        # Components for Run Page
        self.run_text = Text(self.run_frame)
        self.run_text.grid(row=0, column=0, padx=20, pady=20, sticky="nsew")

        # Initial page
        self.show_home_page()

        # Create heading and text in tools_frame
        heading_label = customtkinter.CTkLabel(self.tools_frame, text="Video Editing Tools", font=customtkinter.CTkFont(size=25, weight="bold"))
        heading_label.grid(row=0, column=0, columnspan=5, padx=20, pady=(20, 10))

        description_text = customtkinter.CTkLabel(self.tools_frame, text="Welcome to BladeSense. Create a new video or upload video to get started. ", font=customtkinter.CTkFont(size=18))
        description_text.grid(row=1, column=0, columnspan=5, padx=20, pady=(0, 10))

        description_text = customtkinter.CTkLabel(self.tools_frame, text="Use the buttons below to edit your videos.", font=customtkinter.CTkFont(size=16))
        description_text.grid(row=2, column=0, columnspan=5, padx=20, pady=(0, 10)
                              )
        # Upload Video button
        self.upload_video_button = customtkinter.CTkButton(self.tools_frame, text="\u25B6 Upload Video", command=self.upload_video, font=customtkinter.CTkFont(size=16))
        self.upload_video_button.grid(row=3, column=1, padx=20, pady=(10, 10))

        # Create Video button
        self.create_video_button = customtkinter.CTkButton(self.tools_frame, text="\u25B6 Create Video", command=self.create_video, font=customtkinter.CTkFont(size=16))
        self.create_video_button.grid(row=3, column=2, padx=20, pady=10)

        # Crop Video button
        self.crop_video_button = customtkinter.CTkButton(self.tools_frame, text="Crop Video", command=self.crop_video, font=customtkinter.CTkFont(size=16))
        self.crop_video_button.grid(row=3, column=3, padx=20, pady=10)

        # Trim Video button
        self.trim_video_button = customtkinter.CTkButton(self.tools_frame, text="Trim Video", command=self.trim_video, font=customtkinter.CTkFont(size=16))
        self.trim_video_button.grid(row=3, column=4, padx=20, pady=10)

        # Modify the button creation code with dark grey color
        self.button1 = customtkinter.CTkButton(self.tools_frame, text="\u25B6 How BladeSense works", command=lambda: self.open_pdf_in_browser("C:/Users/Mansi/Downloads/CustomTkinter-master/CustomTkinter-master/examples/phonetics.pdf"), fg_color="#333333", font=customtkinter.CTkFont(size=14))
        self.button1.grid(row=4, column=1, padx=20, pady=(10, 10))

        self.button2 = customtkinter.CTkButton(self.tools_frame, text="\u25B6 Features Overview", command=lambda: self.open_pdf_in_browser("C:/Users/Mansi/Downloads/CustomTkinter-master/CustomTkinter-master/examples/phonetics.pdf"), fg_color="#333333", font=customtkinter.CTkFont(size=14))
        self.button2.grid(row=4, column=2, padx=20, pady=10)

        self.button3 = customtkinter.CTkButton(self.tools_frame, text="\u25B6 Product Walkthrough", command=lambda: self.open_pdf_in_browser("C:/Users/Mansi/Downloads/CustomTkinter-master/CustomTkinter-master/examples/phonetics.pdf"), fg_color="#333333", font=customtkinter.CTkFont(size=14))
        self.button3.grid(row=4, column=3, padx=20, pady=10)

        self.button4 = customtkinter.CTkButton(self.tools_frame, text="\u25B6 Get Help", command=lambda: self.open_pdf_in_browser("C:/Users/Mansi/Downloads/CustomTkinter-master/CustomTkinter-master/examples/phonetics.pdf"), fg_color="#333333", font=customtkinter.CTkFont(size=14))
        self.button4.grid(row=4, column=4, padx=20, pady=10)

        # Load Script button
        self.load_script_button = customtkinter.CTkButton(self.run_frame, text="Load Script", command=self.load_script)
        self.load_script_button.grid(row=0, column=1, padx=20, pady=(10, 10))

        # Run Script button
        self.run_script_button = customtkinter.CTkButton(self.run_frame, text="Run Script", command=self.run_script)
        self.run_script_button.grid(row=0, column=2, padx=20, pady=(10, 10))

        # Variable to store loaded script
        self.loaded_script = None
        
        # Load and display the image
        self.load_image()

    # Inside the App class
    def open_pdf_in_browser(self, pdf_path):
        webbrowser.open_new_tab(pdf_path)


    def load_image(self):
        # Load the image
        self.image = Image.open("C:/Users/Mansi/Downloads/CustomTkinter-master/CustomTkinter-master/examples/home_image.jpg")  # Replace "your_image_path.jpg" with the path to your image file

        # Resize the image if necessary
        self.image = self.image.resize((1040, 660), Image.ANTIALIAS)

        # Convert the image to Tkinter-compatible format
        self.image_tk = ImageTk.PhotoImage(self.image)

        # Create a label to display the image
        self.image_label = tk.Label(self.home_frame, image=self.image_tk, cursor="hand2")
        self.image_label.grid(row=16, column=1, padx=20, pady=(10, 10))
    
    def show_home_page(self):
        # Hide other frames
        self.tools_frame.grid_remove()
        self.documentation_frame.grid_remove()
        self.run_frame.grid_remove()
        self.home_frame.grid(row=0, column=1, padx=20, pady=(10, 10), sticky="nsew")

    def show_tools_page(self):
        # Hide other frames
        self.home_frame.grid_remove()
        self.documentation_frame.grid_remove()
        self.run_frame.grid_remove()
        self.tools_frame.grid(row=0, column=1, padx=20, pady=(10, 10), sticky="nsew")

    def show_documentation_page(self):
        self.tools_frame.grid_remove()
        self.home_frame.grid_remove()
        self.run_frame.grid_remove()
        self.documentation_frame.grid(row=0, column=1, padx=20, pady=(10, 10), sticky="nsew")
        self.load_pdf("C:/Users/Mansi/Downloads/CustomTkinter-master/CustomTkinter-master/examples/phonetics.pdf")

    def show_run_page(self):
        # Hide other frames
        self.home_frame.grid_remove()
        self.documentation_frame.grid_remove()
        # Show Run frame
        self.run_frame.grid(row=1, column=1, padx=20, pady=(10, 10), sticky="nsew")

    def change_scaling_event(self, new_scaling: str):
        new_scaling_float = int(new_scaling.replace("%", "")) / 100
        customtkinter.set_widget_scaling(new_scaling_float)

    def open_input_dialog_event(self):
        dialog = customtkinter.CTkInputDialog(text="Type in a number:", title="CTkInputDialog")
        print("CTkInputDialog:", dialog.get_input())

        # Show run frame
        self.show_run_page()

    def change_appearance_mode_event(self, new_appearance_mode: str):
        customtkinter.set_appearance_mode(new_appearance_mode)
    
    def upload_video(self):
        file_path = filedialog.askopenfilename(filetypes=[("Video Files", "*.mp4;*.avi")])
        if file_path:
            if hasattr(self, 'vlc_player') and self.vlc_player is not None:
                self.vlc_player.stop()
                self.vlc_player.release()

            self.vlc_instance = vlc.Instance('--no-xlib')
            self.vlc_player = self.vlc_instance.media_player_new()
            media = self.vlc_instance.media_new(file_path)
            media.get_mrl()
            self.vlc_player.set_media(media)

            if hasattr(self, 'video_frame') and self.video_frame is not None:
                self.video_frame.destroy()
            
            # Create a new frame for the video
            self.video_frame = customtkinter.CTkFrame(self.tools_frame)
            self.video_frame.grid(row=2, column=2, padx=40, pady=40, sticky="nsew")
            
            # Bind the resize event of the video frame to adjust the video size with frame size
            self.video_frame.bind("<Configure>", self.resize_video_frame)
            self.vlc_player.set_hwnd(self.video_frame.winfo_id())
            self.vlc_player.play()

    def resize_video_frame(self, event):
        if self.vlc_player:
            # Resize the video player to fit the frame size
            self.vlc_player.video_set_size(event.width, event.height)

    def load_script(self):
        file_path = filedialog.askopenfilename(filetypes=[("Python Files", "*.py")])
        if file_path:
            with open(file_path, 'r') as file:
                self.loaded_script = file.read()

    def create_video(self):
        # Placeholder method for creating a video
        pass

    def trim_video(self):
        # Open a dialog box to select the video file
        video_path = filedialog.askopenfilename(filetypes=[("Video Files", "*.mp4;*.avi")])

        if video_path:
            # Open a dialog box to get start and end times
            start_time = tkinter.simpledialog.askstring("Enter Start Time", "Enter start time (in seconds):", parent=self)
            end_time = tkinter.simpledialog.askstring("Enter End Time", "Enter end time (in seconds):", parent=self)

            if start_time is not None and end_time is not None:
                try:
                    start_time = float(start_time)
                    end_time = float(end_time)

                    # Perform video trimming
                    trimmed_video_path = self.perform_video_trim(video_path, start_time, end_time)

                    if trimmed_video_path:
                        messagebox.showinfo("Trim Video", f"Video trimmed successfully and saved as:\n{trimmed_video_path}")
                    else:
                        messagebox.showerror("Trim Video", "Failed to trim video.")
                except ValueError:
                    messagebox.showerror("Invalid Input", "Please enter valid numeric values for start and end times.")

    def perform_video_trim(self, video_path, start_time, end_time):
        try:
            # Load the original video
            video_clip = VideoFileClip(video_path)

            # Trim the video
            trimmed_clip = video_clip.subclip(start_time, end_time)

            # Generate a unique filename for the trimmed video
            trimmed_filename = os.path.splitext(os.path.basename(video_path))[0] + "_trimmed.mp4"
            trimmed_video_path = os.path.join(os.path.dirname(video_path), trimmed_filename)

            # Write the trimmed video to a new file
            trimmed_clip.write_videofile(trimmed_video_path, codec="libx264")

            return trimmed_video_path
        except Exception as e:
            print(f"Error trimming video: {e}")
            return None

    def crop_video(self):
        # Open a dialog box to select the video file
        video_path = filedialog.askopenfilename(filetypes=[("Video Files", "*.mp4;*.avi")])

        if video_path:
            # Open dialog boxes to get crop parameters
            x = tkinter.simpledialog.askinteger("Enter X Coordinate", "Enter X coordinate of top-left corner:")
            y = tkinter.simpledialog.askinteger("Enter Y Coordinate", "Enter Y coordinate of top-left corner:")
            width = tkinter.simpledialog.askinteger("Enter Width", "Enter width of the cropped region:")
            height = tkinter.simpledialog.askinteger("Enter Height", "Enter height of the cropped region:")

            if None not in [x, y, width, height]:
                # Perform video cropping
                cropped_video_path = self.perform_video_crop(video_path, x, y, width, height)

                if cropped_video_path:
                    messagebox.showinfo("Crop Video", f"Video cropped successfully and saved as:\n{cropped_video_path}")
                else:
                    messagebox.showerror("Crop Video", "Failed to crop video.")

    def perform_video_crop(self, video_path, x, y, width, height):
        try:
            # Generate a unique filename for the cropped video
            cropped_filename = os.path.splitext(os.path.basename(video_path))[0] + "_cropped.mp4"
            cropped_video_path = os.path.join(os.path.dirname(video_path), cropped_filename)

            # Use ffmpeg to extract the cropped region
            ffmpeg_extract_subclip(video_path, x, x + width, y, y + height, targetname=cropped_video_path)

            return cropped_video_path
        except Exception as e:
            print(f"Error cropping video: {e}")
            return None 
    
    def run_script(self):
        if self.loaded_script:
            # Clear existing content in the run text widget
            self.run_text.delete(1.0, tkinter.END)

            try:
                # Compile the loaded script
                compiled_script = compile(self.loaded_script, '<string>', 'exec')
                
                # Execute the compiled script within the run text widget
                exec(compiled_script, {'__name__': '__main__', '__file__': '<string>', '__builtins__': __builtins__},
                     {'print': lambda *args, **kwargs: self.run_text.insert(tkinter.END, ' '.join(map(str, args)) + '\n')})
            except Exception as e:
                self.run_text.insert(tkinter.END, f"Error: {str(e)}\n")
        else:
            if self.python_code_text.get(1.0, tkinter.END).strip():
                # Clear existing content in the run text widget
                self.run_text.delete(1.0, tkinter.END)

                try:
                    # Compile the entered Python code
                    compiled_script = compile(self.python_code_text.get(1.0, tkinter.END), '<string>', 'exec')
                    
                    # Execute the compiled script within the run text widget
                    exec(compiled_script, {'__name__': '__main__', '__file__': '<string>', '__builtins__': __builtins__},
                         {'print': lambda *args, **kwargs: self.run_text.insert(tkinter.END, ' '.join(map(str, args)) + '\n')})
                except Exception as e:
                    self.run_text.insert(tkinter.END, f"Error: {str(e)}\n")
            else:
                tkinter.messagebox.showerror("Error", "No script loaded or code entered!")
    def upload_video(self):
        file_path = filedialog.askopenfilename(filetypes=[("Video Files", "*.mp4;*.avi")])
        if file_path:
            self.open_video_window(file_path)

    def open_video_window(self, video_path):
        window = tk.Toplevel(self)
        window.title("Video Player")
        window.geometry("800x600")

        # Create VLC player instance
        vlc_instance = vlc.Instance()
        player = vlc_instance.media_player_new()

        # Load video file
        media = vlc_instance.media_new(video_path)
        player.set_media(media)

        # Create a canvas to display video
        canvas = tk.Canvas(window, bg='black', width=800, height=600)
        canvas.pack(expand=True, fill=tk.BOTH)

        # Set VLC player to draw inside canvas
        player.set_hwnd(canvas.winfo_id())

        # Play the video
        player.play()

        # Close the video player when the window is closed
        window.protocol("WM_DELETE_WINDOW", lambda: self.close_video_window(player, window))

    def close_video_window(self, player, window):
        player.stop()
        window.destroy()

if __name__ == "__main__":
    app = App()
    app.mainloop()