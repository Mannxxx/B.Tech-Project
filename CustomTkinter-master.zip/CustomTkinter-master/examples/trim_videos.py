# # Import everything needed to edit video clips 
# from moviepy.editor import *

# # loading video gfg 
# clip = VideoFileClip("examples/Trim.mp4") 

# # getting only first 5 seconds 
# clip = clip.subclip(10, 14) 

# # # cutting out some part from the clip 
# # clip = clip.cutout(3, 7) 

# # showing clip 
# clip.ipython_display(width = 360)

import cv2

# Function to handle mouse events
def draw_rectangle(event, x, y, flags, params):
    global mouseX, mouseY, drawing, ix, iy
    if event == cv2.EVENT_LBUTTONDOWN:
        drawing = True
        ix, iy = x, y
    elif event == cv2.EVENT_MOUSEMOVE:
        if drawing:
            cv2.rectangle(frame, (ix, iy), (x, y), (0, 255, 0), 2)
    elif event == cv2.EVENT_LBUTTONUP:
        drawing = False
        cv2.rectangle(frame, (ix, iy), (x, y), (0, 255, 0), 2)
        mouseX, mouseY = x, y

# Open video file
video_path = input("C:/Users/Mansi/Downloads/CustomTkinter-master/CustomTkinter-master/examples/Trim.mp4")
cap = cv2.VideoCapture(video_path)

if not cap.isOpened():
    print("Error: Could not open video file.")
    exit()

# Create a window and set mouse callback function
cv2.namedWindow('Select Region', cv2.WINDOW_NORMAL)
cv2.setMouseCallback('Select Region', draw_rectangle)

# Read the first frame
ret, frame = cap.read()
if not ret:
    print("Error: Could not read the video frame.")
    exit()

drawing = False
mouseX, mouseY = -1, -1
ix, iy = -1, -1

# Set window position
cv2.moveWindow('Select Region', 100, 100)

while True:
    cv2.imshow('Select Region', frame)
    key = cv2.waitKey(1) & 0xFF
    if key == ord('q'):
        break
    elif key == ord('c'):
        if mouseX != -1 and mouseY != -1:
            # Crop and extract the selected region
            x1, y1 = min(ix, mouseX), min(iy, mouseY)
            x2, y2 = max(ix, mouseX), max(iy, mouseY)
            cropped_frame = frame[y1:y2, x1:x2]
            cv2.imshow('Cropped Region', cropped_frame)
            output_path = input("C:/Users/Mansi/Downloads/CustomTkinter-master/CustomTkinter-master/examples/cropped_Trim.mp4")
            output_video = cv2.VideoWriter(output_path, cv2.VideoWriter_fourcc(*'mp4v'), 30, (x2 - x1, y2 - y1))
            output_video.write(cropped_frame)
            output_video.release()
            print("Cropped video saved successfully.")
        else:
            print("Error: No region selected.")

cap.release()
cv2.destroyAllWindows()
