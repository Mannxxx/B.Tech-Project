"""
CustomTkinter PDF Viewer widget
Author: Akash Bora
License: MIT
This is a pdf view widger for customtkinter
Homepage: https://github.com/Akascape/CTkPDFViewer
"""

__version__ = '0.1'

from .ctk_pdf_viewer import CTkPDFViewer
